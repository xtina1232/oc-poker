package main;

import evaluation.Evaluator;

public class Main {

	public static void main(String[] args) {
		Evaluator.eval();
	}
}
