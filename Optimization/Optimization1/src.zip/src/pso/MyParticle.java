package pso;

import net.sourceforge.jswarm_pso.Particle;

public class MyParticle extends Particle {
	// Create a 2-dimentional particle
	public MyParticle() {
		super(2);
	}
}